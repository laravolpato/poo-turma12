# 17-ExercicioStreams

Projeto Maven criado automaticamente com Java 21 e JUnit 5.

## Como compilar e rodar

```bash
mvn compile
mvn exec:java -Dexec.mainClass="aagustini.poo.App"
```

## Como rodar testes

```bash
mvn test
```

