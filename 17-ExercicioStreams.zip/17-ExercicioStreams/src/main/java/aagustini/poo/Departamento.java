package aagustini.poo;

public enum Departamento {
    VENDAS, FINANCEIRO, GERENCIA
}
